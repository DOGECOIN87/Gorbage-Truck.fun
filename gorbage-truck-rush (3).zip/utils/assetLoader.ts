import { GameAssets } from '../types';

const loadImage = (src: string): Promise<HTMLImageElement | null> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = src;
    img.onload = () => resolve(img);
    img.onerror = () => {
      console.warn(`Failed to load asset: ${src}. Using fallback graphics.`);
      resolve(null);
    };
  });
};

export const loadGameAssets = async (): Promise<GameAssets> => {
  // Loading the specific assets requested by the user
  const truck = await loadImage('assets/truck.png'); // Keeping existing logic
  const ground = await loadImage('assets/ground.png');
  
  // New specific images
  const trashCan = await loadImage('assets/trash_can.png');
  const gameboy = await loadImage('assets/gameboy.png');
  const introBg = await loadImage('assets/intro_bg.png');

  return {
    truck,
    ground,
    trashCan,
    gameboy,
    introBg,
  };
};