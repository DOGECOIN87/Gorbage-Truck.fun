
import React, { useEffect, useRef, useCallback } from 'react';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  LANE_X_POSITIONS, 
  PLAYER_Z, 
  PLAYER_SIZE,
  LANE_SWITCH_SPEED,
  INITIAL_SPEED,
  SPEED_INCREMENT,
  MAX_SPEED,
  SPAWN_DISTANCE,
  SPAWN_RATE_INITIAL,
  MIN_SPAWN_RATE,
  OBSTACLE_SIZE,
  COLLECTIBLE_VARIANTS,
  MAX_LIVES,
  ITEMS_PER_COMBO,
  CAMERA_HEIGHT,
  CAMERA_DISTANCE,
  FOV,
  HORIZON_Y,
  LANE_WIDTH_3D
} from '../constants';
import { GameState, Entity, EntityType, Player, GameAssets, CollectibleSubtype } from '../types';
import { loadGameAssets } from '../utils/assetLoader';

interface GameRunnerProps {
  gameState: GameState;
  setGameState: (state: GameState) => void;
  setScore: (score: number) => void;
  setLives: (lives: number) => void;
  setMultiplier: (mult: number) => void;
  onGameOver: (finalScore: number) => void;
  musicVolume: number;
  sfxVolume: number;
}

const GameRunner: React.FC<GameRunnerProps> = ({ 
  gameState, 
  setGameState, 
  setScore, 
  setLives,
  setMultiplier,
  onGameOver,
  musicVolume,
  sfxVolume
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  
  // Game State
  const assetsRef = useRef<GameAssets | null>(null);
  const playerRef = useRef<Player>({
    lane: 1,
    x: LANE_X_POSITIONS[1],
    y: 0,
    z: PLAYER_Z,
    width: PLAYER_SIZE.w,
    height: PLAYER_SIZE.h,
    depth: PLAYER_SIZE.d
  });
  const entitiesRef = useRef<Entity[]>([]);
  const gameSpeedRef = useRef<number>(INITIAL_SPEED);
  const speedMilestoneRef = useRef<number>(INITIAL_SPEED);
  const spawnTimerRef = useRef<number>(0);
  const scoreRef = useRef<number>(0);
  const livesRef = useRef<number>(MAX_LIVES);
  const roadOffsetRef = useRef<number>(0);
  
  // Audio State
  const noiseBufferRef = useRef<AudioBuffer | null>(null);
  const nextNoteTimeRef = useRef<number>(0);
  const noteIndexRef = useRef<number>(0);

  // Background Layers for Parallax
  const bgLayersRef = useRef<{
    stars: {x: number, y: number, size: number, opacity: number}[],
    backCity: {x: number, w: number, h: number}[],
    frontCity: {x: number, w: number, h: number}[]
  }>({ stars: [], backCity: [], frontCity: [] });

  // Visual Effects
  const shakeRef = useRef<number>(0);
  
  // Combo Logic
  const comboCountRef = useRef<number>(0);
  const multiplierRef = useRef<number>(1);
  
  // Input
  const touchStartRef = useRef<{x: number, y: number} | null>(null);

  // --- Initialization ---
  useEffect(() => {
    const initAssets = async () => {
      assetsRef.current = await loadGameAssets();
    };
    initAssets();

    if (!audioCtxRef.current) {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContext) {
        const ctx = new AudioContext();
        audioCtxRef.current = ctx;

        // Create Noise Buffer for Hi-Hats
        const bufferSize = ctx.sampleRate * 2; // 2 seconds
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }
        noiseBufferRef.current = buffer;
      }
    }

    // Initialize Procedural Background Layers
    const stars = [];
    for (let i = 0; i < 60; i++) {
      stars.push({
        x: Math.random() * CANVAS_WIDTH,
        y: Math.random() * HORIZON_Y * 0.8, 
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.8 + 0.2
      });
    }

    const backCity = [];
    let currentX = -200;
    while(currentX < CANVAS_WIDTH + 200) {
      const w = 30 + Math.random() * 50;
      const h = 30 + Math.random() * 60;
      backCity.push({ x: currentX, w, h });
      currentX += w - 5;
    }

    const frontCity = [];
    currentX = -200;
    while(currentX < CANVAS_WIDTH + 200) {
      const w = 20 + Math.random() * 40;
      const h = 20 + Math.random() * 40;
      frontCity.push({ x: currentX, w, h });
      currentX += w;
    }

    bgLayersRef.current = { stars, backCity, frontCity };

  }, []);

  const playSound = (type: 'collect' | 'hit' | 'gameover' | 'speedup') => {
    if (sfxVolume <= 0.01 || !audioCtxRef.current) return;
    if (audioCtxRef.current.state === 'suspended') audioCtxRef.current.resume();

    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'collect') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.1 * sfxVolume, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } else if (type === 'hit') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2 * sfxVolume, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } else if (type === 'gameover') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(300, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(100, ctx.currentTime + 1);
      gain.gain.setValueAtTime(0.3 * sfxVolume, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1);
      osc.start();
      osc.stop(ctx.currentTime + 1);
    } else if (type === 'speedup') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(660, ctx.currentTime + 0.4);
      gain.gain.setValueAtTime(0.05 * sfxVolume, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.4);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    }
  };

  // --- Dynamic Music Scheduler ---
  const runMusicScheduler = () => {
    if (musicVolume <= 0.01 || !audioCtxRef.current || gameState !== GameState.PLAYING) return;
    const ctx = audioCtxRef.current;

    const progress = Math.min(1, Math.max(0, (gameSpeedRef.current - INITIAL_SPEED) / (MAX_SPEED - INITIAL_SPEED)));
    const bpm = 120 + (progress * 50);
    const secondsPerBeat = 60.0 / bpm;
    const stepTime = secondsPerBeat / 4; 

    if (nextNoteTimeRef.current < ctx.currentTime - 0.1) {
      nextNoteTimeRef.current = ctx.currentTime + 0.1;
    }

    const lookahead = 0.1; 

    while (nextNoteTimeRef.current < ctx.currentTime + lookahead) {
      playStep(ctx, noteIndexRef.current, nextNoteTimeRef.current);
      nextNoteTimeRef.current += stepTime;
      noteIndexRef.current = (noteIndexRef.current + 1) % 16;
    }
  };

  const playStep = (ctx: AudioContext, step: number, time: number) => {
    const masterGain = 0.3 * musicVolume;
    if (masterGain <= 0.001) return;

    // Kick
    if (step % 4 === 0) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(150, time);
      osc.frequency.exponentialRampToValueAtTime(0.01, time + 0.5);
      gain.gain.setValueAtTime(1.0 * masterGain, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
      osc.start(time);
      osc.stop(time + 0.5);
    }

    // Hi-Hat
    if (step % 4 === 2) {
      if (noiseBufferRef.current) {
        const source = ctx.createBufferSource();
        source.buffer = noiseBufferRef.current;
        const filter = ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = 8000;
        const gain = ctx.createGain();
        source.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        gain.gain.setValueAtTime(0.4 * masterGain, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.05);
        source.start(time);
        source.stop(time + 0.05);
      }
    }

    // Bass
    if (step % 2 === 0) {
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      const gain = ctx.createGain();
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      const notes = [98, 98, 116.5, 98, 130.8, 98, 116.5, 146.8]; 
      const freq = notes[(step / 2) % 8];
      osc.frequency.setValueAtTime(freq, time);
      filter.frequency.setValueAtTime(600, time);
      filter.frequency.exponentialRampToValueAtTime(100, time + 0.15);
      gain.gain.setValueAtTime(0.4 * masterGain, time);
      gain.gain.linearRampToValueAtTime(0, time + 0.2);
      osc.start(time);
      osc.stop(time + 0.2);
    }

    // Arp
    if (step % 3 === 0 && step !== 0) {
      const osc = ctx.createOscillator();
      osc.type = 'square';
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      const arpNotes = [392, 466.1, 523.2, 587.3];
      const freq = arpNotes[(step / 3) % 4];
      osc.frequency.setValueAtTime(freq, time);
      gain.gain.setValueAtTime(0.08 * masterGain, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.1);
      osc.start(time);
      osc.stop(time + 0.1);
    }
  };


  // --- 3D Projection Engine ---

  const project = useCallback((x: number, y: number, z: number) => {
    // 1. Calculate relative depth from camera
    const depth = z + CAMERA_DISTANCE;
    
    // 2. Prevent division by zero or negative depth
    if (depth <= 10) return { x: 0, y: 0, scale: 0, visible: false };

    // 3. Perspective Scaling
    const scale = FOV / depth;

    // 4. Projection
    // x: Center of screen + (World X * Scale)
    const screenX = CANVAS_WIDTH / 2 + x * scale;
    
    // y: Horizon Line + (Relative Height * Scale)
    // Note: y is "up" in 3D world, so we subtract from Camera Height
    const screenY = HORIZON_Y + (CAMERA_HEIGHT - y) * scale;

    return { x: screenX, y: screenY, scale, visible: true };
  }, []);

  // --- Game Logic ---

  const spawnEntity = () => {
    const laneIdx = Math.floor(Math.random() * 3);
    const laneX = LANE_X_POSITIONS[laneIdx];
    
    const isCollectible = Math.random() > 0.55; 
    
    let type = isCollectible ? EntityType.COLLECTIBLE : EntityType.OBSTACLE;
    let subtype: any;
    let dims = OBSTACLE_SIZE;

    if (isCollectible) {
      const rand = Math.random();
      let variantName = 'BOTTLE';
      
      if (rand > 0.85) variantName = 'GAMEBOY';
      else if (rand > 0.60) variantName = 'CAN';
      else if (rand > 0.35) variantName = 'GLASS';
      else variantName = 'BOTTLE';

      subtype = variantName;
      dims = COLLECTIBLE_VARIANTS[variantName];

    } else {
      subtype = 'TRASH_CAN';
      dims = OBSTACLE_SIZE;
    }

    const tooClose = entitiesRef.current.some(e => 
      e.lane === laneIdx && Math.abs(e.z - SPAWN_DISTANCE) < 400
    );

    if (!tooClose) {
      entitiesRef.current.push({
        id: Date.now() + Math.random(),
        type,
        subtype,
        lane: laneIdx,
        x: laneX,
        y: 0, 
        z: SPAWN_DISTANCE,
        width: dims.w,
        height: dims.h,
        depth: dims.d
      });
    }
  };

  const checkCollisions = () => {
    const p = playerRef.current;
    
    entitiesRef.current.forEach(e => {
      if (e.collected) return;

      const depthOverlap = Math.abs(p.z - e.z) < (p.depth + e.depth) / 2;
      const widthOverlap = Math.abs(p.x - e.x) < (p.width + e.width) / 2;

      if (depthOverlap && widthOverlap) {
        if (e.type === EntityType.COLLECTIBLE) {
          e.collected = true;
          
          const variant = COLLECTIBLE_VARIANTS[e.subtype as string] || COLLECTIBLE_VARIANTS['BOTTLE'];
          const baseScore = variant.score;
          
          comboCountRef.current += 1;
          if (comboCountRef.current % ITEMS_PER_COMBO === 0) {
            multiplierRef.current = Math.min(multiplierRef.current + 1, 10);
            setMultiplier(multiplierRef.current);
          }
          scoreRef.current += baseScore * multiplierRef.current;
          setScore(scoreRef.current);
          playSound('collect');
        } else {
          e.collected = true; 
          livesRef.current -= 1;
          setLives(livesRef.current);
          comboCountRef.current = 0;
          multiplierRef.current = 1;
          setMultiplier(1);
          playSound('hit');
          shakeRef.current = 20;
          
          if (livesRef.current <= 0) {
            playSound('gameover');
            handleGameOver();
          }
        }
      }
    });
  };

  const handleGameOver = () => {
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
    setGameState(GameState.GAME_OVER);
    onGameOver(scoreRef.current);
  };

  const resetGame = useCallback(() => {
    playerRef.current = {
        lane: 1,
        x: LANE_X_POSITIONS[1],
        y: 0,
        z: PLAYER_Z,
        width: PLAYER_SIZE.w,
        height: PLAYER_SIZE.h,
        depth: PLAYER_SIZE.d
    };
    entitiesRef.current = [];
    gameSpeedRef.current = INITIAL_SPEED;
    speedMilestoneRef.current = INITIAL_SPEED;
    scoreRef.current = 0;
    livesRef.current = MAX_LIVES;
    comboCountRef.current = 0;
    multiplierRef.current = 1;
    shakeRef.current = 0;
    setScore(0);
    setLives(MAX_LIVES);
    setMultiplier(1);
    spawnTimerRef.current = 0;
    
    if (audioCtxRef.current) {
      nextNoteTimeRef.current = audioCtxRef.current.currentTime + 0.1;
      noteIndexRef.current = 0;
    }
  }, [setScore, setLives, setMultiplier]);

  // --- Rendering Primitives ---

  const drawCube = (ctx: CanvasRenderingContext2D, x: number, y: number, z: number, w: number, h: number, d: number, color: string, topColor: string, sideColor: string) => {
    const hw = w/2; const hd = d/2;
    
    // Project 8 corners
    const fBottomL = project(x - hw, y, z - hd);
    const fBottomR = project(x + hw, y, z - hd);
    const fTopL = project(x - hw, y + h, z - hd);
    const fTopR = project(x + hw, y + h, z - hd);
    const bBottomL = project(x - hw, y, z + hd);
    const bBottomR = project(x + hw, y, z + hd);
    const bTopL = project(x - hw, y + h, z + hd);
    const bTopR = project(x + hw, y + h, z + hd);

    if (!fBottomL.visible) return;

    // Draw Top Face
    ctx.fillStyle = topColor;
    ctx.beginPath();
    ctx.moveTo(fTopL.x, fTopL.y);
    ctx.lineTo(fTopR.x, fTopR.y);
    ctx.lineTo(bTopR.x, bTopR.y);
    ctx.lineTo(bTopL.x, bTopL.y);
    ctx.fill();
    ctx.stroke();

    // Draw Side Faces (only if visible based on x)
    if (x < 0) {
         ctx.fillStyle = sideColor;
         ctx.beginPath();
         ctx.moveTo(fTopR.x, fTopR.y);
         ctx.lineTo(fBottomR.x, fBottomR.y);
         ctx.lineTo(bBottomR.x, bBottomR.y);
         ctx.lineTo(bTopR.x, bTopR.y);
         ctx.fill();
         ctx.stroke();
    }
    if (x > 0) {
        ctx.fillStyle = sideColor;
         ctx.beginPath();
         ctx.moveTo(fTopL.x, fTopL.y);
         ctx.lineTo(fBottomL.x, fBottomL.y);
         ctx.lineTo(bBottomL.x, bBottomL.y);
         ctx.lineTo(bTopL.x, bTopL.y);
         ctx.fill();
         ctx.stroke();
    }
    
    // Draw Front Face
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(fBottomL.x, fBottomL.y);
    ctx.lineTo(fBottomR.x, fBottomR.y);
    ctx.lineTo(fTopR.x, fTopR.y);
    ctx.lineTo(fTopL.x, fTopL.y);
    ctx.fill();
    ctx.stroke();
  };

  const drawSprite = (ctx: CanvasRenderingContext2D, img: HTMLImageElement, x: number, y: number, z: number, w: number, h: number) => {
    // Project center of the sprite
    const p = project(x, y + h/2, z);
    if (!p.visible) return;

    const drawW = w * p.scale;
    const drawH = h * p.scale;

    // Draw shadow
    const shadowP = project(x, 0, z);
    if (shadowP.visible) {
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.beginPath();
        ctx.ellipse(shadowP.x, shadowP.y, drawW/2, drawW/5, 0, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.drawImage(img, p.x - drawW/2, p.y - drawH/2, drawW, drawH);
  };

  // --- Main Draw Loop ---

  const draw = (ctx: CanvasRenderingContext2D) => {
    // Sky Gradient
    const grad = ctx.createLinearGradient(0, 0, 0, HORIZON_Y);
    grad.addColorStop(0, '#0f172a'); 
    grad.addColorStop(1, '#312e81'); 
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    
    const playerX = playerRef.current.x;

    // Stars
    ctx.fillStyle = '#FFF';
    bgLayersRef.current.stars.forEach(s => {
      const offsetX = -playerX * 0.05; 
      let px = s.x + offsetX;
      ctx.globalAlpha = s.opacity;
      ctx.beginPath();
      ctx.arc(px, s.y, s.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1.0;

    // City Layers
    ctx.fillStyle = '#1e1b4b'; 
    bgLayersRef.current.backCity.forEach(b => {
      const offsetX = -playerX * 0.1;
      ctx.fillRect(b.x + offsetX, HORIZON_Y - b.h, b.w, b.h);
    });

    ctx.fillStyle = '#4c1d95'; 
    bgLayersRef.current.frontCity.forEach(b => {
      const offsetX = -playerX * 0.25;
      ctx.fillRect(b.x + offsetX, HORIZON_Y - b.h, b.w, b.h);
    });

    // Ground
    ctx.fillStyle = '#111827'; 
    ctx.fillRect(0, HORIZON_Y, CANVAS_WIDTH, CANVAS_HEIGHT - HORIZON_Y);

    ctx.save();
    
    // Screen Shake
    if (shakeRef.current > 0) {
      const mag = shakeRef.current * 0.5;
      ctx.translate((Math.random()-0.5)*mag, (Math.random()-0.5)*mag);
    }

    // Draw Road Plane
    const roadHalfWidth = (LANE_WIDTH_3D * 3) / 2;
    const zNear = -CAMERA_DISTANCE + 10;
    const zFar = SPAWN_DISTANCE;

    const pNearL = project(-roadHalfWidth, 0, zNear);
    const pNearR = project(roadHalfWidth, 0, zNear);
    const pFarL = project(-roadHalfWidth, 0, zFar);
    const pFarR = project(roadHalfWidth, 0, zFar);

    if (pNearL.visible && pNearR.visible) {
        ctx.fillStyle = '#1f2937';
        ctx.beginPath();
        ctx.moveTo(pNearL.x, pNearL.y);
        ctx.lineTo(pNearR.x, pNearR.y);
        ctx.lineTo(pFarR.x, pFarR.y);
        ctx.lineTo(pFarL.x, pFarL.y);
        ctx.fill();
    }

    // Moving Lane Markers
    roadOffsetRef.current = (roadOffsetRef.current + gameSpeedRef.current) % 400;
    
    ctx.strokeStyle = '#9945FF';
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#9945FF';
    
    const laneDividersX = [
        LANE_X_POSITIONS[0] + LANE_WIDTH_3D/2, 
        LANE_X_POSITIONS[1] + LANE_WIDTH_3D/2
    ];
    
    laneDividersX.forEach(lx => {
       for (let z = -200; z < SPAWN_DISTANCE; z += 400) {
          const zPos = z - roadOffsetRef.current;
          if (zPos < -CAMERA_DISTANCE + 50) continue; 
          
          const p1 = project(lx, 0, zPos);
          const p2 = project(lx, 0, zPos + 200);
          
          if (p1.visible && p2.visible) {
             ctx.lineWidth = Math.max(1, 4 * p1.scale);
             ctx.beginPath();
             ctx.moveTo(p1.x, p1.y);
             ctx.lineTo(p2.x, p2.y);
             ctx.stroke();
          }
       }
    });
    ctx.shadowBlur = 0; 

    // Render Entities (Sorted by depth)
    const renderList = [
      ...entitiesRef.current.map(e => ({ ...e, isPlayer: false })),
      { ...playerRef.current, type: 'PLAYER', subtype: 'TRUCK', isPlayer: true }
    ];

    renderList.sort((a, b) => b.z - a.z);

    renderList.forEach(obj => {
       if (obj.isPlayer) {
          drawPlayer(ctx, obj as Player);
       } else {
          drawEntity(ctx, obj as Entity);
       }
    });

    ctx.restore();
  };

  const drawPlayer = (ctx: CanvasRenderingContext2D, p: Player) => {
    const shadowP = project(p.x, 0, p.z);
    if(shadowP.visible) {
        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.beginPath();
        ctx.ellipse(shadowP.x, shadowP.y, (p.width * shadowP.scale), (p.width * 0.4 * shadowP.scale), 0, 0, Math.PI * 2);
        ctx.fill();
    }

    // Truck Body
    drawCube(ctx, p.x, 20, p.z, p.width, p.height*0.6, p.depth, '#14F195', '#10c479', '#0b8c56');
    // Truck Cabin
    drawCube(ctx, p.x, p.height*0.6, p.z - 20, p.width * 0.9, p.height*0.4, p.depth * 0.4, '#9945FF', '#7c3aed', '#6d28d9');
    
    // Wheels
    const wx = p.width/2 + 5;
    drawCube(ctx, p.x - wx, 10, p.z - 25, 12, 22, 25, '#111', '#333', '#000');
    drawCube(ctx, p.x + wx, 10, p.z - 25, 12, 22, 25, '#111', '#333', '#000');
    drawCube(ctx, p.x - wx, 10, p.z + 25, 12, 22, 25, '#111', '#333', '#000');
    drawCube(ctx, p.x + wx, 10, p.z + 25, 12, 22, 25, '#111', '#333', '#000');
  };

  const drawEntity = (ctx: CanvasRenderingContext2D, e: Entity) => {
     const assets = assetsRef.current;

     if (e.type === EntityType.OBSTACLE) {
       if (assets?.trashCan) {
         drawSprite(ctx, assets.trashCan, e.x, e.y, e.z, e.width, e.height);
       } else {
         const p = project(e.x, e.height/2, e.z);
         if(p.visible) {
             ctx.fillStyle = '#6b7280';
             ctx.fillRect(p.x - (e.width/2)*p.scale, p.y - (e.height/2)*p.scale, e.width*p.scale, e.height*p.scale);
         }
       }
     } else {
       if (e.subtype === 'GAMEBOY' && assets?.gameboy) {
          const bounce = Math.sin(Date.now() / 200) * 8;
          const rotate = Math.sin(Date.now() / 500) * 0.1;
          
          const p = project(e.x, e.y + e.height/2 + bounce, e.z);
          if (!p.visible) return;
          
          const drawW = e.width * p.scale;
          const drawH = e.height * p.scale;
          
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(rotate);
          ctx.drawImage(assets.gameboy, -drawW/2, -drawH/2, drawW, drawH);
          ctx.restore();

       } else {
          let color = '#fff';
          if (e.subtype === 'BOTTLE') color = '#3b82f6';
          else if (e.subtype === 'CAN') color = '#ef4444';
          else if (e.subtype === 'GLASS') color = '#10b981';

          const bounce = Math.sin(Date.now() / 300) * 5;
          const yPos = e.y + 10 + bounce;
          
          drawCube(
             ctx, 
             e.x, 
             yPos, 
             e.z, 
             e.width, 
             e.height, 
             e.depth, 
             color, 
             '#ffffff', 
             color
          );
       }
     }
  };

  const update = () => {
    if (gameState !== GameState.PLAYING) return;

    if (shakeRef.current > 0) shakeRef.current--;
    if (gameSpeedRef.current < MAX_SPEED) {
        gameSpeedRef.current += SPEED_INCREMENT;
        
        if (gameSpeedRef.current > speedMilestoneRef.current + 5) {
            playSound('speedup');
            speedMilestoneRef.current = Math.floor(gameSpeedRef.current);
        }
    }

    const targetX = LANE_X_POSITIONS[playerRef.current.lane];
    playerRef.current.x += (targetX - playerRef.current.x) * LANE_SWITCH_SPEED;
    
    entitiesRef.current.forEach(e => {
       e.z -= gameSpeedRef.current;
    });

    entitiesRef.current = entitiesRef.current.filter(e => e.z > -CAMERA_DISTANCE - 100 && !e.collected);

    spawnTimerRef.current--;
    if (spawnTimerRef.current <= 0) {
       spawnEntity();
       const rate = Math.max(MIN_SPAWN_RATE, SPAWN_RATE_INITIAL - (gameSpeedRef.current - INITIAL_SPEED)*1.5);
       spawnTimerRef.current = rate;
    }

    checkCollisions();
  };

  const loop = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    update();
    draw(ctx);
    
    if (gameState === GameState.PLAYING) {
      runMusicScheduler();
      requestRef.current = requestAnimationFrame(loop);
    } else if (gameState === GameState.MENU) {
        draw(ctx);
    }
  }, [gameState]);

  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      if (audioCtxRef.current?.state === 'suspended') audioCtxRef.current.resume();
      resetGame();
      requestRef.current = requestAnimationFrame(loop);
    } else {
        const t = setTimeout(() => loop(), 100);
        return () => clearTimeout(t);
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState, loop, resetGame]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== GameState.PLAYING) return;
      if (['ArrowLeft', 'a', 'A'].includes(e.key)) moveLane(-1);
      else if (['ArrowRight', 'd', 'D'].includes(e.key)) moveLane(1);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  const moveLane = (dir: number) => {
    playerRef.current.lane = Math.max(0, Math.min(2, playerRef.current.lane + dir));
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const dx = e.changedTouches[0].clientX - touchStartRef.current.x;
    const dy = e.changedTouches[0].clientY - touchStartRef.current.y;
    if (Math.abs(dx) > 30 && Math.abs(dx) > Math.abs(dy)) {
       moveLane(dx > 0 ? 1 : -1);
    }
    touchStartRef.current = null;
  };

  useEffect(() => {
    (window as any).gameMoveLeft = () => moveLane(-1);
    (window as any).gameMoveRight = () => moveLane(1);
    return () => {
      delete (window as any).gameMoveLeft;
      delete (window as any).gameMoveRight;
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={CANVAS_WIDTH}
      height={CANVAS_HEIGHT}
      className="w-full h-full object-cover block"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    />
  );
};

export default GameRunner;
